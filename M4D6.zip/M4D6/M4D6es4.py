def trova_minimo(lista):
    if len(lista) == 0:
        raise ValueError("La lista è vuota.")

    minimo = lista[0]
    posizione_minimo = 0

    for i in range(1, len(lista)):
        if lista[i] < minimo:
            minimo = lista[i]
            posizione_minimo = i

    return minimo, posizione_minimo

# Esempio di utilizzo della funzione
lista_input = input("Inserisci gli elementi della lista separati da spazi: ").split()
lista = [int(elemento) for elemento in lista_input]

try:
    minimo, posizione_minimo = trova_minimo(lista)
    print("Elemento più piccolo:", minimo)
    print("Posizione:", posizione_minimo)
except ValueError as e:
    print("Errore:", str(e))
