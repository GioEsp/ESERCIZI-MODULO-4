sequenza = input("Inserisci una sequenza di interi separati da spazi: ")
numeri = sequenza.split()
interi = []

for numero in numeri:
    try:
        interi.append(int(numero))
    except ValueError:
        interi.append("ValueError")

# Costruzione della tabella incrociata
tabella = []
for numero1 in interi:
    riga = []
    for numero2 in interi:
        if isinstance(numero1, int) and isinstance(numero2, int):
            # isinstance(numero1, int) per verificare se numeroX è di tipo int 
            riga.append(numero1 * numero2)
        else:
            riga.append("ValueError")
    tabella.append(riga)

# Visualizzazione della tabella incrociata
for riga in tabella:
    for valore in riga:
        print(valore, end="\t")
    print()
