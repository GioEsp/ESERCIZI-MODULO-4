def suddividi_in_righe(lista, lunghezza_righe):
    if len(lista) % lunghezza_righe != 0:
        raise ValueError("La lunghezza della sequenza non è un multiplo della lunghezza delle righe.")

    righe = [lista[i:i+lunghezza_righe] for i in range(0, len(lista), lunghezza_righe)]
    return righe

lista_input = input("Inserisci gli elementi della lista separati da spazi: ").split()
lunghezza_righe = int(input("Inserisci la lunghezza delle righe: "))

if len(lista_input) % lunghezza_righe != 0:
    print("Errore: La lunghezza della sequenza non è un multiplo della lunghezza delle righe.")
else:
    risultato = suddividi_in_righe(lista_input, lunghezza_righe)
    print("Lista suddivisa in righe:")
    for riga in risultato:
        print(riga)
