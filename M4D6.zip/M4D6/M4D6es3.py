def verifica_presenza_numero(sequenza, numero):
    if numero in sequenza:
        return True
    else:
        return False

# Esempio di utilizzo della funzione
sequenza_input = input("Inserisci una sequenza di interi separati da spazi: ").split()
numero_input = input("Inserisci il numero da cercare: ")

sequenza = [int(elemento) for elemento in sequenza_input]
numero = int(numero_input)

if verifica_presenza_numero(sequenza, numero):
    print("Il numero", numero, "fa parte della sequenza.")
else:
    print("Il numero", numero, "non fa parte della sequenza.")
