"""
    Un multiset è una collezione di elementi con la loro frequenza. Esempio: 
    multiset con due banane e 3 mele.
    Un multiset può essere implementato come dizionario 
    (le chiavi sono gli elementi, i valori sono le frequenze).
    Scrivi un programma con le funzioni unione, intersezione e differenza 
    che ricevono in input due multiset
    e restituiscono in output il multiset unione (somma delle frequenze),
    il multiset intersezione (il minimo tra le frequenze)
    e infine quello differenza 
    (differenza tra le frequenze, non deve essere minore di zero).
    Visualizza il risultato.
"""

""" 
    Vengono definiti due multiset m_1 e m_2 con le rispettive 
    frequenze degli elementi. 
    Viene quindi creato un insieme keys che contiene tutte le chiavi 
    dei due multiset combinati. 
"""
m_1 = {"apple": 3, "orange": 7, "banana": 4}
m_2 = {"apple": 9, "banana": 9}
keys = set(m_1.keys()).union(m_2.keys())

""" La funzione union_ms prende in input i due multiset (d1 e d2) 
    insieme all'insieme di chiavi. Crea un nuovo dizionario d_union vuoto 
    che conterrà il multiset unione. 
    Successivamente itera su ogni chiave presente nell'insieme keys. 
    Per ogni chiave, recupera la frequenza dell'elemento nei 
    multiset d1 e d2 utilizzando il metodo get(). 
    Quindi calcola la somma delle frequenze e assegna il risultato 
    al dizionario d_union utilizzando la chiave corrispondente. 
    Alla fine, restituisce il multiset unione.
"""
def union_ms(d1, d2, keys):
    d_union = {}

    for key in keys:
        freq1 = d1.get(key, 0)  # prende il totale della chiave altrimenti 0
        freq2 = d2.get(key, 0)
        d_union[key] = freq1 + freq2

    return d_union

"""
    La funzione intersect_ms è simile a union_ms ma calcola l'intersezione 
    dei due multiset. 
    Crea un nuovo dizionario d_intersect vuoto per memorizzare 
    il multiset intersezione. 
    Itera su ogni chiave presente nell'insieme keys e recupera le frequenze
    degli elementi nei multiset d1 e d2. 
    Utilizzando la funzione min(), calcola il minimo tra le due frequenze 
    e assegna il risultato a min_freq. 
    Se min_freq è maggiore di zero viene assegnato al 
    dizionario d_intersect utilizzando la chiave corrispondente. 
    Alla fine, restituisce il multiset intersezione.
"""
def intersect_ms(d1, d2, keys):
    d_intersect = {}

    for key in keys:
        freq1 = d1.get(key, 0)
        freq2 = d2.get(key, 0)
        min_freq = min(freq1, freq2)   # valore minimo tra i due
        if min_freq > 0:
            d_intersect[key] = min_freq

    return d_intersect

"""
    La funzione diff_ms calcola la differenza tra i multiset. 
    Crea un nuovo dizionario d_diff vuoto per memorizzare il 
    multiset differenza. 
    Itera su ogni chiave nell'insieme keys e recupera le frequenze degli 
    elementi nei multiset d1 e d2. Calcola la differenza tra le frequenze
    utilizzando l'operatore - e assegna il risultato a diff. 
    Se la differenza è maggiore di zero, viene assegnata a d_diff utilizzando
    la chiave corrispondente. Alla fine, restituisce il multiset differenza.
"""
def diff_ms(d1, d2, keys):
    d_diff = {}

    for key in keys:
        freq1 = d1.get(key, 0)
        freq2 = d2.get(key, 0)
        diff = freq1 - freq2
        if diff > 0:
            d_diff[key] = diff
        elif diff < 0:
            d_diff[key] = -diff

    return d_diff

# Calcola l'unione dei multiset
multiset_union = union_ms(m_1, m_2, keys)
print("Multiset unione:", multiset_union)

# Calcola l'intersezione dei multiset
multiset_intersection = intersect_ms(m_1, m_2, keys)
print("Multiset intersezione:", multiset_intersection)

# Calcola la differenza dei multiset
multiset_difference = diff_ms(m_1, m_2, keys)
print("Multiset differenza:", multiset_difference)
