# Trasforma tutte le consonanti in maiuscolo
def trasforma_consonanti_maiuscolo(stringa):
    vocali = "AEIOUaeiou"
    nuova_stringa = ""

    for carattere in stringa:
        if carattere not in vocali:
            nuova_stringa += carattere.upper()
        else:
            nuova_stringa += carattere

    return nuova_stringa

# Chiedi all'utente di inserire una stringa
stringa_input = input("Inserisci una stringa: ")

# Stampa il risultato
risultato = trasforma_consonanti_maiuscolo(stringa_input)
print("Risultato:", risultato)

# Costruiamo il dizionario
def costruisci_dizionario(stringa):
    dizionario = {}

   # Splitto la stringa in parole
    parole = risultato.split()

    # Itero sulle parole
    for parola in parole:
        # Itero sulle lettere della parola
        for lettera in parola:
            # Se la lettera è una lettera minuscola
            if lettera.islower():
                # Aggiungo la parola al valore corrispondente nella chiave del dizionario
                if lettera in dizionario:
                    dizionario[lettera].append(parola)
                else:
                    dizionario[lettera] = [parola]

    return dizionario

# Costruisci il dizionario
dizionario_risultato = costruisci_dizionario(stringa_input)

# Stampa il risultato
for lettera, parole in dizionario_risultato.items():
    print(lettera + ":", tuple(parole))



